import 'bootstrap/dist/css/bootstrap.min.css';

import EntryForm from './Containers/EntryForm'


function App() {
  return (
    <div className="App">
        <EntryForm></EntryForm>
      </div>
  );
}

export default App;
